<?php
session_start();

// Simulação de roteamento simples
$request = $_SERVER['REQUEST_URI'];

if ($request == '/') {
    require '../app/views/home.php';
} elseif (strpos($request, '/login') === 0) {
    $controller = new AuthController();
    $controller->login();
} elseif (strpos($request, '/logout') === 0) {
    $controller = new AuthController();
    $controller->logout();
} elseif (strpos($request, '/candidates') === 0) {
    $controller = new CandidateController();
    $controller->index();
} elseif (strpos($request, '/votes') === 0) {
    $controller = new VoteController();
    $controller->index();
} else {
    header('HTTP/1.0 404 Not Found');
    echo 'Página não encontrada';
}
