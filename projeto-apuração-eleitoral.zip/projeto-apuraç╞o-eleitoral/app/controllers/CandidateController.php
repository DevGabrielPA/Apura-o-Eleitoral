
<?php

class CandidateController {
    public function index() {
        $candidates = Candidate::all();
        require '../app/views/candidates/index.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Candidate::create($_POST);
            header('Location: /candidates');
        }
        require '../app/views/candidates/create.php';
    }
}

?>