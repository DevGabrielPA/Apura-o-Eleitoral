<?php
session_start();

class AuthController {
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Lógica de autenticação
            $_SESSION['user'] = $_POST['username'];
            header('Location: /home');
        }
        require '../app/views/auth/login.php';
    }

    public function logout() {
        session_destroy();
        header('Location: /login');
    }
}





?>