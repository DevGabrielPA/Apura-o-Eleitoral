
<?php
class VoteController {
    public function index() {
        $votes = Vote::all();
        require '../app/views/votes/index.php';
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            Vote::create($_POST);
            header('Location: /votes');
        }
        $candidates = Candidate::all(); // Para selecionar um candidato
        require '../app/views/votes/create.php';
    }
}

?>