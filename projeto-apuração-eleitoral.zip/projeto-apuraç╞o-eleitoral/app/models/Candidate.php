<?php

class Candidate {
    public static function all() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT * FROM candidates");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create($data) {
        $db = Database::getConnection();
        $stmt = $db->prepare("INSERT INTO candidates (name, party) VALUES (?, ?)");
        $stmt->execute([$data['name'], $data['party']]);
    }
}

?>