
<?php
class Vote {
    public static function all() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT votes.*, candidates.name AS candidate_name FROM votes JOIN candidates ON votes.candidate_id = candidates.id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function create($data) {
        $db = Database::getConnection();
        $stmt = $db->prepare("INSERT INTO votes (candidate_id, voter_id) VALUES (?, ?)");
        $stmt->execute([$data['candidate_id'], $data['voter_id']]);
    }
}

?>
