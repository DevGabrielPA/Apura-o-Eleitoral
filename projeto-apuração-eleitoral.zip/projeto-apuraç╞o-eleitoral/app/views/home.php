<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>
    <h1>Bem-vindo ao Sistema de Apuração Eleitoral</h1>
    <footer>
        <a href="https://github.com/ArthurHosken/ArthurHosken">Arthur</a> |
        <a href="https://github.com/lmachadopa35">Lucas</a> |
        <a href="https://github.com/GabrielPonciano1/TPA">Gabriel Pociano</a>
       <a href=" https://github.com/DevGabrielPA/DevGabrielPA"> Gabriel Patricio</a>
    </footer>
</body>
</html>