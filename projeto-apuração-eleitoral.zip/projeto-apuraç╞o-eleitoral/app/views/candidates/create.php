<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Candidato</title>
    <link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
    <h1>Adicionar Candidato</h1>
    <form action="" method="POST">
        <input type="text" name="name" placeholder="Nome" required>
        <input type="text" name="party" placeholder="Partido" required>
        <button type="submit">Adicionar</button>
    </form>
</body>
</html>
