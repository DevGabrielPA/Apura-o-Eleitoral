<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Candidatos</title>
    <link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
    <h1>Candidatos</h1>
    <a href="/candidates/create">Adicionar Candidato</a>
    <ul>
        <?php foreach ($candidates as $candidate): ?>
            <li><?php echo $candidate['name'] . ' - ' . $candidate['party']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
