<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Voto</title>
    <link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
    <h1>Adicionar Voto</h1>
    <form action="" method="POST">
        <select name="candidate_id" required>
            <?php foreach ($candidates as $candidate): ?>
                <option value="<?php echo $candidate['id']; ?>"><?php echo $candidate['name']; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="voter_id" placeholder="ID do Votante" required>
        <button type="submit">Votar</button>
    </form>
</body>
</html>
