<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Votos</title>
    <link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
    <h1>Votos</h1>
    <a href="/votes/create">Adicionar Voto</a>
    <ul>
        <?php foreach ($votes as $vote): ?>
            <li><?php echo "Votante: " . $vote['voter_id'] . " - Candidato: " . $vote['candidate_name']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
